function y = gc1(x)
y = [1; 0; 1];
end
