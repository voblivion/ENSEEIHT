function y = mhc1(x)
y = [0 0 0; 0 0 0; 0 0 0];
end
