clear all
g = [-2; 1];
h = [-2 0; 0 10];
s = pasDeCauchy(g, h, 10)
