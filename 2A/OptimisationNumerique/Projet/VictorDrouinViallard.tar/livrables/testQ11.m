clear all
g = [0; 0];
h = [7 0; 0 2];
s = pasDeCauchy(g, h, 1)
