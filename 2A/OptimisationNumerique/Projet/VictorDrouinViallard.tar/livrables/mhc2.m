function y = mgc2(x)
y = [2 0; 0 2];
end
