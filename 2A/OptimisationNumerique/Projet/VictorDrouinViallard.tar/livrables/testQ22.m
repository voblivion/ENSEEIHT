clear all
g = [6; 2];
h = [7 0; 0 2];
s = pasDeCauchy(g, h, 0.5)
