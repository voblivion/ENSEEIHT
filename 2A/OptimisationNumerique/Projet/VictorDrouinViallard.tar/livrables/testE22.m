clear all
lambda = newtonNonLineaire([2 20], [-38 20], 0.7, -75, -25)
