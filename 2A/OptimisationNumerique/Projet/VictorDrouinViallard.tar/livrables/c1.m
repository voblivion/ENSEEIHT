function y = c1(x)
y = [x(1) + x(3) - 1];
end
