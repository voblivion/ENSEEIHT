function hx = h1(x)
    hx = [6 2 4; 2 8 2; 4 2 6];
end