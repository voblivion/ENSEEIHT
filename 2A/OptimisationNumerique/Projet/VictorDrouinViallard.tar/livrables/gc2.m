function y = gc2(x)
y = [2*x(1); 2*x(2)];
end
