clear all
lambda = newtonNonLineaire([2 6], [2 14], 0.5, -50, 0)
