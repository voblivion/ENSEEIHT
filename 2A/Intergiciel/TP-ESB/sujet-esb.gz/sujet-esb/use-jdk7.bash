#!/bin/bash

export JAVA_HOME=/mnt/n7fs/ens/tp_dh/jdk1.7.0_79
export PATH=$JAVA_HOME/bin:$PATH

